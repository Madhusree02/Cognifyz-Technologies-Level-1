# Cognifyz-Technologies-Leve-1
Task-1 : Top Cuisines ♨️

"Analyzing data deliciously! 🍽 Just determined the top three most common cuisines in our dataset and calculated the percentage of restaurants serving each one.

Task-2 : City Analysis 🏙

✅Identified the city with the highest number of restaurants and calculated the average rating for restaurants in each city. Thrilled to unveil the city boasting the highest average rating!🤩

Task-3 : Price Range Distribution 🔖

📈Visualized the distribution of price ranges among restaurants using a histogram/bar chart and calculated the percentage of restaurants in each category. ⭐Discovering patterns to elevate customer experiences!

Task-4 : Online Delivery 🚚

🚀Uncovered the percentage of eateries offering online delivery and compared the average ratings between those with and without this service. 🧬Valuable insights for enhancing dining experiences!
